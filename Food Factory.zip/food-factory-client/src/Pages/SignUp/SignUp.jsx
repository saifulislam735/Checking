// import React from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { FaGoogle, FaFacebookF, FaApple, FaGithub } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useContext, useState } from 'react';
import { AuthContext } from '../../Provider/AuthProvider';

const SignUp = () => {
  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')
  const { createUser } = useContext(AuthContext)

  const handleCreateUser = (event) => {
    event.preventDefault()
    const form = event.target;
    const email = form.email.value;
    const password = form.password.value;
    const name = form.name.value;
    console.log(form, email, password, name)

    setSuccess('')
    setError('')

    createUser(email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        console.log(user)
        setSuccess('Account created successfully')
        setTimeout(() => setSuccess(''), 3000)
        form.reset()
      })
      .catch((error) => {
        const errorMessage = error.message;
        setError(errorMessage)
        setTimeout(() => setError(''), 6000)
      })

  }

  return (
    <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
      <Row>
        <Col>
          <div className="p-4 border rounded" style={{ backgroundColor: '#fff' }}>
            <h3 className="mb-4 text-center">Create your Free Account</h3>
            <Form onSubmit={handleCreateUser}>
              <Form.Group controlId="formFullName" className="mb-3">
                <Form.Label >Full Name</Form.Label>
                <Form.Control type="text" name='name' placeholder="Enter your full name" />
              </Form.Group>

              <Form.Group controlId="formEmail" className="mb-3">
                <Form.Label>Email</Form.Label>
                <Form.Control type="email" name='email' placeholder="Enter your email" />
              </Form.Group>

              <Form.Group controlId="formPassword" className="mb-3">
                <Form.Label>Password</Form.Label>
                <Form.Control type="password" name='password' placeholder="Enter your password" />
              </Form.Group>

              <Button variant="primary" type="submit" className="w-100 mb-3">
                Create
              </Button>

              <div className="text-center">
                <p>Already have an account? <a href="/login">Log in</a></p>
              </div>
              {error &&
                <p className='text-danger text-center'>{error}</p>
              }
              {success &&
                <p className='text-success text-center'>{success}</p>
              }
              <div className="text-center mt-3">
                <p>or sign in with</p>
                <Button variant="outline-danger" className="m-1">
                  <FaGoogle />
                </Button>
                <Button variant="outline-primary" className="m-1">
                  <FaFacebookF />
                </Button>
                <Button variant="outline-dark" className="m-1">
                  <FaApple />
                </Button>
                <Button variant="outline-secondary" className="m-1">
                  <FaGithub />
                </Button>
              </div>
            </Form>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default SignUp;
