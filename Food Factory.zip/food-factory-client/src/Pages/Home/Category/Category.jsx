import { useState, useEffect } from 'react';
import { Container, Row, Col, Form, Dropdown, DropdownButton, InputGroup } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';

const Category = () => {
    const [selectedCategory, setSelectedCategory] = useState('Recipes');
    const [selectedChief, setSelectedChief] = useState('Chief');
    const [categories, setCategories] = useState([]);
    const [chiefByCountry, setChiefByCountry] = useState('');

    useEffect(() => {
        fetch('https://food-factory-server-53ub7bpp9-shihabs-projects-a8b59b65.vercel.app/cuisine') // Adjust URL based on your JSON server setup
            .then(res => {
                if (!res.ok) {
                    throw new Error('Network response was not ok ' + res.statusText);
                }
                return res.json();
            })
            .then(data => {
                const category = data.map(item => item.cuisine_name);
                const uniqueCuisine = [...new Set(category)];
                setCategories(uniqueCuisine);

                const chiefs = data.filter(item => item.cuisine_name === selectedCategory);
                setChiefByCountry(chiefs);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }, [selectedCategory]);

    return (
        <Container className="mt-5">
            <Row className="mb-4">
                <Col xs={12} md={8}>
                    <InputGroup>
                        <DropdownButton
                            variant="outline-secondary"
                            title={selectedCategory}
                            id="input-group-dropdown-1"
                            onSelect={(eventKey) => setSelectedCategory(eventKey)}
                        >
                            {categories.map((category, index) => (
                                <Dropdown.Item key={index} eventKey={category}>
                                    <Link className="text-decoration-none text-black" to={`cuisine/${category}`}>
                                        {category}
                                    </Link>
                                </Dropdown.Item>
                            ))}
                        </DropdownButton>
                        <Form.Control
                            type="text"
                            placeholder="Find a recipe..."
                            aria-label="Find a recipe"
                            aria-describedby="basic-addon2"
                        />
                    </InputGroup>
                </Col>
                <Col xs={6} md={4} className="d-flex">
                    <DropdownButton
                        variant="outline-secondary"
                        title={selectedChief}
                        id="input-group-dropdown-1"
                        onSelect={(eventKey) => setSelectedChief(eventKey)}
                    >
                        <div className="p-2">
                            {chiefByCountry &&
                                chiefByCountry.map((item, index) => (
                                    <Link to={`chief/${item.chef_id}`} className="text-decoration-none text-black" key={index}>
                                        <p>{item.chef_name}</p>
                                    </Link>
                                ))}
                        </div>
                    </DropdownButton>
                </Col>
            </Row>
        </Container>
    );
};

export default Category;
