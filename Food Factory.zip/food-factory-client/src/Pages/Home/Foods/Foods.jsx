import { useLoaderData } from "react-router-dom";
import Food from "./Food";

const Foods = () => {
    const cuisineByCountryName = useLoaderData()
    console.log(cuisineByCountryName)
    return (
        <div className="d-flex justify-content-center align-items-center vh-100 gap-3">
            {
                cuisineByCountryName.map((cn, index) => <Food key={index} food={cn}></Food>)
            }
        </div>
    );
};

export default Foods;