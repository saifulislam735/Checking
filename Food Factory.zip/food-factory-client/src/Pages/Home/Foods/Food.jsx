import { Card } from "react-bootstrap";
import Box from '@mui/material/Box';
import Rating from '@mui/material/Rating';
// import Typography from '@mui/material/Typography';

const Food = ({ food }) => {
    const { cuisine_name, cuisine_title, chef_name, cuisine_rating, cuisine_details, cuisine_image } = food;
    // console.log(food)
    const rating = Math.floor(cuisine_rating)
    return (
        <Card style={{ width: '20rem', height: '65%' }}>
            <Card.Img
                variant="top"
                src={cuisine_image}
                alt={`${cuisine_name}-${cuisine_title}`}
                style={{
                    objectFit: 'cover',  // Ensure the image covers the whole space
                    height: '50%'      // Control the width of the image
                }}
            />
            <Card.Body>
                <Card.Title>{cuisine_title}</Card.Title>
                <Card.Text>
                    <div className="me-2 d-flex align-items-center">
                        <Box sx={{ mr: 1 }}>
                            <Rating
                                name="read-only"
                                value={rating}
                                readOnly
                            />
                        </Box>
                        <div>{cuisine_rating}</div>
                    </div>
                    {/* Replace with actual rating stars */}
                    <p>{cuisine_details}</p>
                </Card.Text>
                <Card.Footer className="text-muted d-flex justify-content-between align-items-center">
                    <small>{chef_name}</small>
                    <div>
                        <span className="me-3">Desserts</span>
                        <span>1 hr 20 mins</span>
                    </div>
                </Card.Footer>
            </Card.Body>
        </Card>
    );
};

export default Food;
