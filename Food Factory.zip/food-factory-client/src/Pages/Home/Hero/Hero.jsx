// Hero.jsx
// import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import './Hero.css'; // Custom styles
import heroImage1 from '../../../assets/hero1.jpg'
import heroImage2 from '../../../assets/hero2.jpg'
import heroImage3 from '../../../assets/hero3.jpg'

const Hero = () => {
    return (
        <div className="hero-section">
            <Container>
                <Row>
                    <Col md={12} className="text-center">
                        <h1 className="hero-title">GOOD FOOD</h1>
                        <p className="hero-subtitle">Is the foundation of genuine happiness.</p>
                    </Col>
                </Row>
            </Container>
            <div className="hero-images">
                <img src={heroImage1} alt="Image 1" className="hero-image hero-image1" />
            <img src={heroImage2} alt="Image 2" className="hero-image hero-image2" />
                <img src={heroImage3} alt="Image 3" className="hero-image hero-image3" />
            </div>
        </div>
    );
};

export default Hero;
