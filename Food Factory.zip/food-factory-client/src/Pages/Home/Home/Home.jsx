
const Home = () => {
    return (
        <div>
            <p>this is home</p>
        </div>
    );
};

export default Home;