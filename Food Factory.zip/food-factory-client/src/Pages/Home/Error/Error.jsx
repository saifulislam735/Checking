// import React from 'react';
import { Container, Row, Col, Button, Image } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';

const Error = () => {
    const navigate = useNavigate();

    const handleGoHome = () => {
        navigate('/');
    };


    return (
        <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
            <Row>
                <Col className="text-center">
                    <Image
                        src="https://via.placeholder.com/400x300?text=404+Error"
                        fluid
                        className="mb-4"
                        alt="404 Error"
                    />
                    <h1 className="display-4">Oops! Page Not Found</h1>
                    <p className="lead mb-4">
                        The page you are looking for does not exist or an error occurred. Please go back to the homepage or contact support.
                    </p>
                    <Button variant="primary" onClick={handleGoHome}>
                        Go to Homepage
                    </Button>
                </Col>
            </Row>
        </Container>
    );
};

export default Error;
