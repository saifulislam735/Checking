// import React from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { FaGoogle, FaFacebookF, FaApple, FaGithub } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useContext, useState } from 'react';
import { AuthContext } from '../../Provider/AuthProvider';

const Login = () => {
  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')
  const { Login } = useContext(AuthContext)

  const handleSignIn = (event) => {
    event.preventDefault()
    const form = event.target;
    const email = form.email.value;
    const password = form.password.value;
    console.log(form, email, password)

    setSuccess('')
    setError('')

    Login(email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        console.log(user)
        setSuccess('Logged in sucessfully')
        setTimeout(() => setSuccess(''), 3000)
        form.reset()
      })
      .catch((error) => {
        const errorMessage = error.message;
        setError(errorMessage)
        setTimeout(() => setError(''), 6000)
      })

  }
  return (
    <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
      <Row>
        <Col>
          <div className="p-4 border rounded" style={{ backgroundColor: '#fff' }}>
            <h3 className="mb-4 text-center">Log In</h3>
            <Form onSubmit={handleSignIn}>
              <Form.Group controlId="formEmail" className="mb-3">
                <Form.Label>Email</Form.Label>
                <Form.Control name='email' type="email" placeholder="Enter your email" />
              </Form.Group>

              <Form.Group controlId="formPassword" className="mb-3">
                <Form.Label>Password</Form.Label>
                <Form.Control name='password' type="password" placeholder="Enter your password" />
              </Form.Group>

              <Button variant="primary" type="submit" className="w-100 mb-3">
                Log In
              </Button>

              <div className="text-center">
                <p>Do not have an account? <a href="/signup">Sign Up</a></p>
              </div>
              {error &&
                <p className='text-danger text-center'>{error}</p>
              }
              {success &&
                <p className='text-success text-center'>{success}</p>
              }
              <div className="text-center mt-3">
                <p>or sign in with</p>
                <Button variant="outline-danger" className="m-1">
                  <FaGoogle />
                </Button>
                <Button variant="outline-primary" className="m-1">
                  <FaFacebookF />
                </Button>
                <Button variant="outline-dark" className="m-1">
                  <FaApple />
                </Button>
                <Button variant="outline-secondary" className="m-1">
                  <FaGithub />
                </Button>
              </div>

            </Form>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default Login;
