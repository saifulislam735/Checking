// import React from 'react';
import { Container, Row, Col, Card, Image, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useContext } from 'react';
import { AuthContext } from '../../Provider/AuthProvider';

const UserProfile = () => {
    const { logout, user } = useContext(AuthContext)
    // console.log(user.email)
    return (
        <Container className="" style={{ minHeight: '100vh' }}>
            <Card className='mx-auto' style={{ width: '24rem', padding: '20px', borderRadius: '15px' }}>
                <Row className="mb-3">
                    <Col className="text-center">
                        <Image
                            src={
                                user.photoURL ?
                                    user.photoURL
                                    :
                                    "https://via.placeholder.com/150"
                            }
                            roundedCircle
                            fluid
                            style={{ width: '150px', height: '150px' }}
                        />
                    </Col>
                </Row>
                <Card.Body className="text-center">
                    <Card.Title>{user.displayName ?
                        user.displayName : 'User'}</Card.Title>
                    <Card.Subtitle className="mb-2 text-muted">{user.email}</Card.Subtitle>
                    <Card.Text>
                        A passionate developer with expertise in web technologies. Loves to create beautiful and functional user interfaces.
                    </Card.Text>
                </Card.Body>
            </Card>
            <div className='text-center my-4 '>
                <Button onClick={logout} className='mx-auto px-4 py-2'>Logout</Button>

            </div>
        </Container>
    );
};

export default UserProfile;
