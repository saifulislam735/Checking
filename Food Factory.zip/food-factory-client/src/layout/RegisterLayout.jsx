import { Outlet } from "react-router-dom";
import Header from "../Shared/Header/Header";
import NavigationBar from "../Shared/NavigationBar/NavigationBar";
import Footer from "../Shared/Footer/Footer";

const RegisterLayout = () => {
    return (
        <div>
            <Header></Header>
            <NavigationBar></NavigationBar>

            <Outlet></Outlet>

            <Footer></Footer>

            
        </div>
    );
};

export default RegisterLayout;