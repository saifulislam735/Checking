import { Container } from "react-bootstrap";
import Header from "../Shared/Header/Header";
import Footer from "../Shared/Footer/Footer";
import NavigationBar from "../Shared/NavigationBar/NavigationBar";
import Category from "../Pages/Home/Category/Category";
import { Outlet } from "react-router-dom";
import Pagination from "../Pages/Pagination/Pagination";
import Hero from "../Pages/Home/Hero/Hero";

const Main = () => {
    return (
        <div>
            <Header></Header>
            <NavigationBar></NavigationBar>
            <Hero></Hero>
            <Container>
                <Category></Category>
                <Outlet></Outlet> {/*foods will appear here*/}
                <Pagination></Pagination>
            </Container>
            <Footer></Footer>
        </div>
    );
};

export default Main;