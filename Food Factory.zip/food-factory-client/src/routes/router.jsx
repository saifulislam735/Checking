import { createBrowserRouter } from "react-router-dom";
import Main from "../layout/Main";
import Foods from "../Pages/Home/Foods/Foods";
import RegisterLayout from "../layout/RegisterLayout";
import SignUp from "../Pages/SignUp/SignUp";
import Login from "../Pages/Login/Login";
import UserProfile from "../Pages/UserProfile/UserProfile";
import Error from "../Pages/Home/Error/Error";
import FoodByChief from "../Pages/Home/Foods/FoodByChief";

const router = createBrowserRouter([
    {
        path: "/",
        element: <Main></Main>,
        children: [
            {
                path: "cuisine/:name",
                element: <Foods></Foods>,
                loader: ({ params }) => fetch(`http://localhost:3000/cuisine/${params.name}`)
            },
            {
                path: "chief/:id",
                element: <FoodByChief></FoodByChief>,
                loader: ({ params }) => fetch(`http://localhost:3000/chief/${params.id}`)
            }
        ],
    },
    {
        path: "/",
        element: <RegisterLayout></RegisterLayout>,
        children: [
            {
                path: "/signup",
                element: <SignUp></SignUp>,
            },
            {
                path: '/login',
                element: <Login></Login>
            },
            {
                path: '/user',
                element: <UserProfile></UserProfile>
            },
        ],
    },
    {
        path: '*',
        element: <Error></Error>
    }
]);

export default router;