// Header.jsx
// import React from 'react';
import { Navbar, Nav, Form, FormControl, Button } from 'react-bootstrap';
import { FaUser } from 'react-icons/fa';
import './Header.css'; // Custom styles
import { Link } from 'react-router-dom';

const Header = () => {
    return (
        <Navbar bg="light" expand="lg" className="header-navbar">
            <Navbar.Brand href="#" className="header-brand">FOODBAY</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="ml-auto d-flex gap-2">
                    <Link className="text-decoration-none " to="/">Home</Link>
                    <Link className="text-decoration-none " to="/">Menu</Link>
                    <Link className="text-decoration-none " to="/">About</Link>
                    <Link className="text-decoration-none " to="/">Contact</Link>
                </Nav>
                <Form  className="ml-auto">
                    <FormControl type="text" placeholder="Search here" className="mr-sm-2" />
                    <Button variant="outline-dark" className="header-search-button">Search</Button>
                </Form>
                <Nav className="ml-auto">
                    <Link to="signup" className="header-link">Sign Up</Link>
                    <Link to="login" className="header-link">Log In</Link>
                    <Link to="user" className="header-link"><FaUser /></Link>
                </Nav>
            </Navbar.Collapse>
        </Navbar>
    );
};

export default Header;
