// Footer.jsx
// import React from 'react';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { FaFacebookF, FaTwitter, FaInstagram, FaYoutube } from 'react-icons/fa';
import './Footer.css'; // Custom styles

const Footer = () => {
  return (
    <footer className="footer bg-dark text-white py-5">
      <Container>
        <Row>
          <Col md={4}>
            <h5 className="footer-heading">Subscribe</h5>
            <p className="footer-text">Register and get notified about all the news & updates before it gets too late.</p>
            <Form>
              <Form.Group className="d-flex">
                <Form.Control
                  type="email"
                  placeholder="Your email address"
                  className="me-2 footer-input"
                />
                <Button variant="warning" className="footer-button">Sign up</Button>
              </Form.Group>
            </Form>
          </Col>
          <Col md={4}>
            <h5 className="footer-heading">Explore</h5>
            <ul className="list-unstyled footer-links">
              <li><a href="#" className="text-white footer-link">Browse Recipes</a></li>
              <li><a href="#" className="text-white footer-link">Submit a Recipe</a></li>
              <li><a href="#" className="text-white footer-link">Our Chefs</a></li>
              <li><a href="#" className="text-white footer-link">Latest News</a></li>
              <li><a href="#" className="text-white footer-link">Contact</a></li>
            </ul>
          </Col>
          <Col md={4}>
            <h5 className="footer-heading">Contact</h5>
            <address className="footer-text">
              787 Mark View Street,<br />
              New Town, California<br />
              <a href="mailto:needhelp@thatix.com" className="text-white footer-link">needhelp@thatix.com</a><br />
              <a href="tel:+16668880000" className="text-white footer-link">666 888 0000</a>
            </address>
          </Col>
        </Row>
        <Row className="pt-3">
          <Col className="text-center">
            <a href="#" className="text-white mx-2 footer-social"><FaFacebookF /></a>
            <a href="#" className="text-white mx-2 footer-social"><FaTwitter /></a>
            <a href="#" className="text-white mx-2 footer-social"><FaInstagram /></a>
            <a href="#" className="text-white mx-2 footer-social"><FaYoutube /></a>
          </Col>
        </Row>
        <Row className="pt-3">
          <Col className="text-center">
            <p className="footer-text">All rights reserved. Your company name here.</p>
          </Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Footer;
