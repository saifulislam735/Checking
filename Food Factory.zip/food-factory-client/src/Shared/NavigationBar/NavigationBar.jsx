
const NavigationBar = () => {
    return (
        <div>
            {/* <p>this is navigation bar</p> */}
        </div>
    );
};

export default NavigationBar;