
# FOOD-FACTORY-CLIENT

## Project Structure


FOOD-FACTORY-CLIENT
│
├── node_modules/        # Project dependencies
│
├── public/              # Public assets and files
│
├── src/                 # Source files
│   ├── assets/          # Images, fonts, icons, and other static assets
│   │
│   ├── firebase/        # Firebase configuration and initialization
│   │
│   ├── layout/          # Layout components (e.g., Navbar, Footer)
│   │
│   ├── Pages/           # Page components (e.g., Home, Login, Registration, 404)
│   │
│   ├── Provider/        # Context Providers (e.g., AuthProvider)
│   │
│   ├── routes/          # Routing components and configurations
│   │
│   ├── Shared/          # Shared components (e.g., buttons, modals)
│   │
│   ├── utils/           # Utility functions and helpers
│   │
│   ├── App.css          # Global CSS styles
│   ├── App.jsx          # Main App component
│   ├── index.css        # Index CSS styles
│   ├── main.jsx         # Main entry point
│
├── .env.local           # Local environment variables
├── .eslintrc.cjs        # ESLint configuration
├── .gitignore           # Git ignore file
├── index.html           # Main HTML file
├── package-lock.json    # Lockfile for npm
├── package.json         # Project metadata and dependencies
├── README.md            # Project documentation
└── vite.config.js       # Vite configuration
