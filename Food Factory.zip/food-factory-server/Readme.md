# vercel_file: https://food-factory-server-l6f2ng6c8-shihabs-projects-a8b59b65.vercel.app/

#
# https://food-factory-server-nnd7nzu04-shihabs-projects-a8b59b65.vercel.app /new
# https://food-factory-server-2g0oq6rqp-shihabs-projects-a8b59b65.vercel.app
# https://food-factory-server-3zsr63vev-shihabs-projects-a8b59b65.vercel.app


# https://food-factory-server-53ub7bpp9-shihabs-projects-a8b59b65.vercel.app /last

# https://food-factory-server-2xu1uxlym-shihabs-projects-a8b59b65.vercel.app -last