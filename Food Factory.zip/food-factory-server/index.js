const express = require('express');
const cors = require('cors');
const cuisineCategory = require('./data/categoryCuisine.json');
const Cuisine = require('./data/cuisine.json');
const app = express();
const port = 3000;

const corsOptions = {
    origin: 'http://localhost:5173', // Your frontend domain
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type'],
    // credentials: true // Allow credentials if needed
};

app.use();
app.use(express.json());

app.get('/', (req, res) => {
    res.send('Hi World!');
    console.log('Hi World!');
});

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
});

app.get('/cuisine', (req, res) => {
    res.send(cuisineCategory);
});

app.get('/cuisine/:name', (req, res) => {
    const cuisineName = req.params.name;
    const cuisineByCountryName = Cuisine.filter(cuisine => cuisine.cuisine_name.toLowerCase() === cuisineName.toLowerCase());
    if (cuisineByCountryName.length > 0) {
        res.send(cuisineByCountryName);
    } else {
        res.status(404).send({ message: 'Cuisine not found' });
    }
});

app.get('/chief/:id', (req, res) => {
    const cuisineId = req.params.id;
    const cuisineByCountryId = Cuisine.filter(cuisine => cuisine.chef_id === parseInt(cuisineId));
    if (cuisineByCountryId.length > 0) {
        res.send(cuisineByCountryId);
    } else {
        res.status(404).send({ message: 'Cuisine not found' });
    }
});
